#include <iostream>
#include "Menu.h"
#include "Triangolo.h"


using namespace std;

int main(  )
{
    cout << "QUESTO PROGRAMMINO STAMPA \nFIGURE SU TERMINALE.\n\n";
    Menu::menu();

    return 0;
}
