#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include <iostream>

class Menu
{
    public:
        static void menu();
};

#endif // MENU_H_INCLUDED
