#ifndef CONTROLLO_H_INCLUDED
#define CONTROLLO_H_INCLUDED
#include <iostream>

class Controllo
{
    public:
        static void controllo(int l,int a);
};

#endif // CONTROLLO_H_INCLUDED
